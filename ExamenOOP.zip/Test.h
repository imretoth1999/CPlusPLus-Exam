#pragma once
class Test
{
public:
	void testAll();
	void testRemove();
	void testAdd();
	void testUpdate();
};